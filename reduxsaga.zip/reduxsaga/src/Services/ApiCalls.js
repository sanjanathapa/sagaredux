import Axios from "./Axios";
import * as API from "./URLS";

export const LOGIN_USER = (data) => Axios.post(API.LOGIN_USER, data);


export const ADD_USER = (data) => Axios.post(API.ADD_USER, data);