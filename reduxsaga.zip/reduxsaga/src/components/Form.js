import React, { useState } from 'react'
import { useDispatch } from "react-redux";
import { loginUser } from './store/actions';

const Form = () => {

    const [inputs, setInputs] = useState({email: "", password: ""});
    const dispatch = useDispatch();

    const handleChange = (event) => {
        console.log("events-----", event)
        const name = event.target.name;
        const value = event.target.value;
        setInputs(values => ({ ...values, [name]: value }))
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        const data = {
            email: inputs.email,
            password: inputs.password

        }
        console.log(data, "data---------")
        dispatch(loginUser(data))
    }

    return (
        <form onSubmit={handleSubmit}>
            <label>email:
                <input
                    type="text"
                    name="email"
                    value={inputs.email}
                    onChange={handleChange}
                //   onChange={(event)=>setName(event.target.value)}
                />
            </label>
            <label>password:
                <input
                    type="password"
                    name="password"
                    value={inputs.password || ""}
                    onChange={handleChange}
                />
            </label>
            <input type="submit" />
        </form>

    )
}
// const mapDispatchToProps = (dispatch) => ({
//     actions: {
//         getPosts: () => {
//             dispatch(actionType.getPosts());
//         },
//         addPost: (payload) => {
//             dispatch(actionType.addPost(payload));
//         },
//         deletePost: (payload) => {
//             dispatch(actionType.deletePost(payload));
//         },
//         updatePost: (payload) => {
//             dispatch(actionType.updatePost(payload));
//         }
//     },
// });


// const mapDispatchToProps = dispatch => ({
//     onAddFdDriver: (storeType, data, history) =>
//       dispatch(addFdDriver(storeType, data, history)),
//   })

//   export default connect(mapStateToProps, mapDispatchToProps)(Form);
export default Form