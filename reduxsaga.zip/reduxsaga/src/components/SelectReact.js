import React, { useState, useEffect } from 'react';
import Select from "react-select";

const options = [
  { value: "chocolate", label: "Chocolate", id: 1 },
  { value: "strawberry", label: "Strawberry", id: 2 },
  { value: "vanilla", label: "Vanilla", id: 3 },
];

export default function SelectReact() {
  const [selectedOption, setSelectedOption] = useState();


  const [arr, setArr] = useState([]);

  const onChangeHandler = (e, ind) => {
    console.log(selectedOption, "true false", e, ind)
    if (!selectedOption) {
      return;
    }

    setSelectedOption((p) => {
        console.log(p, "p-------------", JSON.stringify(p))
        console.log(...JSON.parse(JSON.stringify(p)), "parsing")
        console.log([...JSON.parse(JSON.stringify(p))], "parsing thing ")
      const newarr = [...JSON.parse(JSON.stringify(p))];
      newarr[ind].inputValue = e.target.value;
console.log(newarr, "jjjjj")
      return newarr;
    });
  };
// This updates the selectedOption state using the setSelectedOption function. It utilizes the 
// functional form of setSelectedOption, which takes the previous state (p) as an argument. Inside this
//function, a new array newarr is created by deep cloning the previous state using 
//JSON.parse(JSON.stringify(p)). Then, the inputValue property of the element at index ind in newarr is
//  updated with the value from the event object e. Finally, the updated newarr is returned, which 
// becomes the new state value for selectedOption.

// In summary, the onChangeHandler function is responsible for updating the inputValue property of the 
// selected option at the specified index based on the input value entered by the user. It ensures that
//  the state is updated immutably by creating a deep copy of the previous state and then modifying the
//  necessary properties before setting the new state.

// The use of JSON.stringify() followed by JSON.parse() in this context is a common pattern for creating
//  a deep copy of an object in JavaScript. Let's break down why this pattern is used:





  useEffect(() => {
    console.log(selectedOption, "selectedOption");

    setArr((p) => {
      return selectedOption?.map((item) => ({
        id: item.id,
        value: item.inputValue || "",
      }));
    });
  }, [selectedOption]);


//   useEffect(() => {
//     console.log(arr,  "arr 115");
//   }, [arr]);

  return (
    <div
      className="App"
      style={{
        display: "flex",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          width: 500,
        }}
      >
        <Select
          value={selectedOption}
        //   onChange={(e) => {console.log(e, "e") return ( setSelectedOption(e))}}
          onChange={(e) => { console.log(e, "e"); setSelectedOption(e); }}
          options={options}
          isMulti={true}
        />
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
        }}
      >
        {selectedOption?.map((item, ind) => {
          return (
            <>
              <label
                style={{
                  height: 15,
                  padding: '6px',
                  margin: '7px'
                }}
              >
                {item?.label || ""}
              </label>
              <input
                onChange={(e) => onChangeHandler(e, ind)}
                value={item.inputValue || ""}
              />
            </>
          );
        })}
      </div>
    </div>
  );
}

// export default App;

