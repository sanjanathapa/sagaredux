// On receiving GET_DATA action it invokes fetchData method. fetchPosts invokes the api service method and pass the response data to another action method GOT_POSTS.


import { call, put, takeEvery, takeLatest } from "redux-saga/effects";
import axios from "axios";
import { toast } from "react-toastify";
import * as API from "../../Services/ApiCalls"

// import { GET_DATA } from './actionTypes'
import { loginUser, loginUser_Success, loginUser_Fail, addCustomer_Success, addCustomer_Fail} from './actions'
import { LOGIN_USER, LOGIN_USER_FAIL, LOGIN_USER_SUCCESS, ADD_CUSTOMER} from "./actionTypes";

// function* fetchData() {
//     try {
//       const response = yield call(api)
//       yield put(getData(response))
//     } catch (error) {
//       yield put(getData(error))
//     }
//   }

//  export default function* getDataSaga() {
//     yield takeEvery(GET_DATA, fetchData);
// }

//////Axios-----------------------------------
// const API_URL = "https://clincept-api.suffescom.dev/api/v1/";
// class Axios {
//   defaultOptions = () => {
//     if (typeof window === "undefined") {
//       return {
//         baseURL: `${API_URL}`,
//         headers: {
//           token: "",
//           customerid: "",
//         },
//       };
//     }
//     return {
//       baseURL: `${API_URL}`,
//       headers: {
//         token: (localStorage && localStorage.getItem("token")) || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InN1cGVyYWRtaW5AZ21haWwuY29tIiwiX2lkIjoiNjQ0YjU2YjVhZjJiOGZjMzMwNDY2ZTU0IiwiaWF0IjoxNzE4MTkyNDk4LCJleHAiOjE3MTgxOTk2OTh9.oGaR1-doHHuWJkTYsLLx59w-h9puAQXToth26q2bYK4",
//         adminid: (localStorage && localStorage.getItem("_id")) || "644b56b5af2b8fc330466e54",
//       },
//     };
//   };

//   post = (url, data, options = {}) => {
//     console.log("url", url, data)
//     return axios
//       .post(url, data, { ...this.defaultOptions(), ...options })
//       .then((res) => {
//         if (res.data.message && res.data.message.includes("Not Authorized")) {
//           let err = {
//             response: {
//               status: 401,
//             },
//           };
//           this.LogoutUser(err);
//         } else {
//           return res;
//         }
//       })
//       .catch((err) => {
//         if (err.response && err.response.status === 401) {
//           this.LogoutUser(err);
//           return err;
//         } else {
//           return err;
//         }
//       });
//   };

// }
//add this saga to redux middleware
// const loginApi= (data) => Axios.post(API.LOGIN_USER, data);
// const customerApi = (data) => Axios.post(API.ADD_USER, data)


function* loginUserSaga({ payload, callBack }) {
  try {
    const response = yield call(API.LOGIN_USER, payload);
    if (response.data.status == "success") {
      toast.success(response.data.message);
      localStorage.setItem("token", response.data.data.token);
      localStorage.setItem("_id", response.data.data._id);
      yield put(loginUser_Success(response.data.data));
    } else {
      toast.error(response.data.message);
      yield put(loginUser_Fail("error"));
    }
  } catch (error) {
    yield put(loginUser_Fail(error));
  }
}

export function* LoginSaga() {
  yield takeEvery(LOGIN_USER, loginUserSaga);
}

function* customerDataSaga({ payload}) {
  console.log(payload, "payload-------payload")
  try {
    const response = yield call(API.ADD_USER, payload);
    console.log(response, "response of customers--------")
    if (response.data.status == "success") {
      toast.success(response.data.message);
      yield put(addCustomer_Success(response.data.data));
    } else {
      toast.error(response.data.message);
      yield put(addCustomer_Fail("error"));
    }
  } catch (error) {
    yield put(addCustomer_Fail(error));
  }
}
export function* AddCustomerSaga(){
  yield takeEvery(ADD_CUSTOMER, customerDataSaga)
}
// export default LoginSaga;