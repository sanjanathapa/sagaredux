export const ADD_DATA = "ADD_DATA"
export const DELETE_DATA= "DELETE_DATA"
export const UPDATE_DATA = "UPDATE_DATA"
export const FETCH_DATA = "FETCH_DATA"

/////////////-----------------Login Action------------------///////////
export const LOGIN_USER = "LOGIN_USER";
export const LOGIN_USER_SUCCESS = "LOGIN_USER_SUCCESS";
export const LOGIN_USER_FAIL = "LOGIN_USER_FAIL";


/////////////===============Add Customer----------------------------
export const ADD_CUSTOMER = "ADD_CUSTOMER";
export const ADD_CUSTOMER_SUCCESS = "ADD_CUSTOMER_SUCCESS";
export const ADD_CUSTOMER_FAIL = "ADD_CUSTOMER_FAIL"