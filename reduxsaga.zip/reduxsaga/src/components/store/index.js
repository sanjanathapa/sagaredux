// import { createStore, applyMiddleware, } from "redux";
// import { createSagaMiddleware } from "redux-saga";

// import { dataReducer } from "./reducer";

// import { getDataSaga} from "./saga";

// const sagaMiddleware = createSagaMiddleware();

// const reduxDevTools =
//     window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__();

// const middleware =
//     window.__REDUX_DEVTOOLS_EXTENSION__ && process.env.NODE_ENV === "development"
//         ? compose(applyMiddleware(sagaMiddleware), reduxDevTools)
//         : applyMiddleware(sagaMiddleware);


// export const store = createStore(dataReducer, middleware);


// sagaMiddleware.run(getDataSaga);

// 1. Redux Setup
import { createStore, applyMiddleware, combineReducers } from 'redux';
import createSagaMiddleware from 'redux-saga';
// import rootReducer from './reducers';
import { LoginReducer, CustomerReducer } from './reducer';
// import rootSaga from './sagas';
import { LoginSaga, AddCustomerSaga } from './saga';


// Combine reducers into a single root reducer
const rootReducer = combineReducers({
    login: LoginReducer,
    customer: CustomerReducer
});
const sagaMiddleware = createSagaMiddleware();


const store = createStore(
    rootReducer,
    applyMiddleware(sagaMiddleware)
);

// 2. Redux Saga Setup
sagaMiddleware.run(LoginSaga);
sagaMiddleware.run(AddCustomerSaga)

export default store;
