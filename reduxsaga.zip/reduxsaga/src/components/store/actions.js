
import { LOGIN_USER_FAIL, LOGIN_USER, LOGIN_USER_SUCCESS, ADD_CUSTOMER, ADD_CUSTOMER_SUCCESS,ADD_CUSTOMER_FAIL } from "./actionTypes";

export const addCustomer = (payload) =>{
  console.log("cutomer payload", payload)
  return {
    type: ADD_CUSTOMER,
    payload: {...payload}
  }
}

export const addCustomer_Success = (payload) => ({
  type: ADD_CUSTOMER_SUCCESS,
  payload,
});

export const addCustomer_Fail = (payload) => ({
  type: ADD_CUSTOMER_FAIL,
  payload,
});


//--------------------------------------------------------------
//-------------Login User--------------------------------------
export const loginUser = (payload, callBack) => {
  console.log("payload--------------", payload)
  return {
    type: LOGIN_USER,
    payload: { ...payload },
    callBack,
  };
};

export const loginUser_Success = (payload) => ({
  type: LOGIN_USER_SUCCESS,
  payload,
});

export const loginUser_Fail = (payload) => ({
  type: LOGIN_USER_FAIL,
  payload,
});
