import { GET_DATA, ADD_DATA, UPDATE_DATA, DELETE_DATA } from "./actionTypes";
import { LOGIN_USER_FAIL, LOGIN_USER, LOGIN_USER_SUCCESS, ADD_CUSTOMER, ADD_CUSTOMER_FAIL, ADD_CUSTOMER_SUCCESS } from "./actionTypes";


const intialState = {
    isLogin: false,
    loading: false,
    user: [],
  
    token: (localStorage && localStorage.getItem("Token")) || null,
    // userName: (localStorage && localStorage.getItem("userName")) || null,   not saving right now
    error: null,
  };

// export const dataReducer = (state= initState, action)=>{
//     switch(action.type){
//         case GET_DATA:{
//             return {
//                 ...state,
//                 data: action.payload,
//               };
//         }
//     }
// }

export const LoginReducer = (state = intialState, action) => {
    switch (action.type) {
      case LOGIN_USER:
        return {
          ...state,
          isLogin: true,
          loading: true,
  
          error: null,
        };
      case LOGIN_USER_SUCCESS:
        return {
          ...state,
          loading: true,
          token: action.payload.token,
          user: action.payload,
          error: null,
        };
      case LOGIN_USER_FAIL:
        return {
          ...state,
          loading: false,
  
          error: action.payload,
        };
  
      default:
        return state;
  
        break;
    }
  };
  
// export default LoginReducer;

export const CustomerReducer = (state = intialState, action) => {
  switch (action.type) {
    case ADD_CUSTOMER:
      return {
        ...state,
        loading: true,

        error: null,
      };
    case ADD_CUSTOMER_SUCCESS:
      return {
        ...state,
        loading: true,
        user: action.payload,
        error: null,
      };
    case ADD_CUSTOMER_FAIL:
      return {
        ...state,
        loading: false,

        error: action.payload,
      };

    default:
      return state;

      break;
  }
};

