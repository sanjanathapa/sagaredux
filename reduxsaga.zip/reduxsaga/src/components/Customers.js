import React, {useState} from "react";
import "./styles.css";
import { useDispatch } from "react-redux";
import { addCustomer } from "./store/actions";

export default function Customers() {

    const [inputs, setInputs] = useState({email: "", password: "", mobile: "", name: "",address: "", countryCode:""});
    const [errors, setErrors] = useState({})
    const dispatch = useDispatch();

  
  const handleChange = (event) => {
    const { name, value } = event.target;
    setInputs((prevInputs) => ({ ...prevInputs, [name]: value }));

    // Validation checks
    let error = {};
    if (name === "email") {
      error.email = !/\S+@\S+\.\S+/.test(value) ? "Invalid email address" : "";
    } else if (name === "mobile") {
      error.mobile = !/^\d{10}$/.test(value) ? "Mobile number must be 10 digits" : "";
    }
    setErrors(error);
  };

    const handleSubmit = (event) => {
        event.preventDefault();
        const data = {
            email: inputs.email,
            password: inputs.password,
            mobileNumber: inputs.mobileNumber,
            name: inputs.name,
            countryCode: inputs.countryCode,
            address: inputs.address

        }
        console.log(data, "data---------")
        dispatch(addCustomer(data))
    }
  return (
    <div className="App">
      <form onSubmit={handleSubmit}>
      <div className="form-control">
          <label>Name</label>
          <input type="text" name="name" value={inputs.name} onChange={handleChange} required/>
        </div>
        <div className="form-control">
          <label>Code</label>
          <input type="number" name="countryCode" value={inputs.countryCode} onChange={handleChange} required/>
        </div>
        <div className="form-control">
          <label>Mobile No.</label>
          <input type="number" name="mobileNumber" value={inputs.mobileNumber} onChange={handleChange} required/>
          {errors.mobile}
        </div>
        
        <div className="form-control">
          <label>Email</label>
          <input type="text" name="email" value={inputs.email} onChange={handleChange} required/>
          {errors.email}
        </div>
        <div className="form-control">
          <label>Password</label>
          <input type="password" name="password" value={inputs.password} onChange={handleChange} required/>
        </div>
        <div className="form-control">
          <label>Address</label>
          <input type="text" name="address" value={inputs.address} onChange={handleChange} required/>
        </div>
        <div className="form-control">
          <label></label>
          <button type="submit">Submit</button>
        </div>
      </form>
    </div>
  );
}