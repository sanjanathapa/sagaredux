import logo from './logo.svg';
import Form from './components/Form';
import Customers from './components/Customers';
import { Routes, Route, Navigate, Outlet } from "react-router-dom";

import './App.css';
import SelectReact from './components/SelectReact';

function App() {
  return (
    <div className="App">
       <Routes>
          <Route path="/" element={<Form />} />
          <Route path="/customers" element={<Customers />} />
          <Route path="/select" element={<SelectReact />} />
        <Route path="*" element={<h1>Page not found</h1>} />
      </Routes>
    </div>
  );
}

export default App;
